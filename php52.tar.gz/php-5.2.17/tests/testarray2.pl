for ($i="aaa"; $i lt "bbb"; $i++) {
	print "$i\n";
}
